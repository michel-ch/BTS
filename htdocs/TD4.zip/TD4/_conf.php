<?php
$serveurBDD="localhost";
$userBDD="root";
$mdpBDD="";
$nomBDD="PROJET_CHEN";

/*
$serveurBDD="db5007010250.hosting-data.io";
$userBDD="dbu1687988";
$mdpBDD="bestofBDD";
$nomBDD="dbs5787713";
*/


?>
