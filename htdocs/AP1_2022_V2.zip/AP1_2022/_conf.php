<?php
$serveurBDD="localhost";
$userBDD="root";
$mdpBDD="";
$nomBDD="AP1_2022";
?>
