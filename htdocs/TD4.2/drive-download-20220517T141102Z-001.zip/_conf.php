<?php
$serveurBDD="localhost";
$userBDD="root";
$mdpBDD="";
$nomBDD="TD4";

/*
$serveurBDD="db5007010250.hosting-data.io";
$userBDD="dbu1687988";
$mdpBDD="bestofBDD";
$nomBDD="dbs5787713";
*/


?>
