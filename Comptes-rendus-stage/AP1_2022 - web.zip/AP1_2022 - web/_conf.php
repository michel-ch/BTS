<?php
$serveurBDD="db5011599821.hosting-data.io";
$userBDD="dbu2888130";
$mdpBDD="#entreebddmichel";
$nomBDD="dbs9779360";
?>
