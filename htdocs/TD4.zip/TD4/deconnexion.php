<?php

session_start();

session_destroy();

echo "déconnexion effectuée. merci de votre visite !<br><br>";

?>

<html>
<head>
</head>
<body>
<a href="index.php">Page d'accueil</a>
</body>
</html>
