<html>
<head> <link href="style.css" media="all" rel="stylesheet" type="text/css"/> </head>
<body>
   

<?php

session_start(); 
include '_conf.php';

if (isset($_POST['envoi'])) //reçois données rentrée lors de la connexion
{
   
    $login = $_POST['login'];
    $mdp =  md5($_POST['mdp']);

    $connexion = mysqli_connect($serveurBDD,$userBDD,$mdpBDD,$nomBDD);
    $requete="Select * from utilisateur WHERE login = '$login' AND motdepasse= '$mdp'"; //recupere données utilisateur 
    //echo "<br> ma req SQL : $requete <br>";
    $resultat = mysqli_query($connexion, $requete);
    $trouve=0;
    while($donnees = mysqli_fetch_assoc($resultat))
      {
   
        $trouve=1;
        $type=$donnees['type'];
        $login=$donnees['login'];
        $id=$donnees['num'];
     // echo "je créé mes sessions !!!";
        $_SESSION["id"]=$id; //relie variable avec session
        $_SESSION["login"]=$login;
        $_SESSION["type"]=$type;
    
      }

    if($trouve==0)
    {
        echo "erreur de connexion";
    }
}
if (isset($_SESSION["login"]))
 
    {
        if($_SESSION["type"]==0)
        {
          ?>
         <ul class="nav">
        <li><a href="accueil.php">Accueil</a></li>
        <li><a href="perso.php">Profil</a></li>
        <li><a href="cr.php">Compte rendus</a></li>
        <li><a href="ccr.php">Nouveau compte-rendu</a></li>
        </ul>
 
            <?php
            echo "<br>Bienvenue sur le compte élève <br> <br>";
            echo "Vous êtes connecté en tant que ".$_SESSION["login"]."<br> <br>";
           echo "<FORM method='post' action='index.php'> <button type=submit name='deco'> DECONNEXION </button> </form>";
        }
        else
        {
?>
              <ul class="nav">
        <li><a href="accueil.php">Accueil</a></li>
        <li><a href="perso.php">Profil</a></li>
        <li><a href="cr.php">Compte rendus</a></li>
        </ul> </html>
<?php
            echo "<br>";
            echo "vous êtes un prof<br>";
            echo "<br>";
            echo "Vous êtes connecté en tant que ".$_SESSION["login"]."<br> <br>";
            echo "<table border=1><tr>
                  <th> Numéro compte rendu </th>
                  <th> Date </th>
                  <th> Numéro utilisateur </th>
                  <th> Nom </th>
                  <th> Prenom </th>
                  <th> Email </th>
                  <th> Option</th></tr>";
            if($connexion = mysqli_connect($serveurBDD,$userBDD,$mdpBDD,$nomBDD))
            {
                $requete="SELECT cr.* FROM cr,utilisateur WHERE utilisateur.num = cr.num_utilisateur ORDER BY date DESC LIMIT 5"; //recupere tous les comptes rendus par date decroissante
                $resultat = mysqli_query($connexion, $requete);
                while($donnees = mysqli_fetch_assoc($resultat))
                {
                    $num=$donnees['num'];
                    $date=$donnees['date'];
                    $numutilisateur=$donnees['num_utilisateur'];
                    echo "<tr><th><FORM method='post' action='cr.php' ><button type=submit name='compte' >$num </button></FORM></th>
                    <th> $date </th>
                    <th>$numutilisateur</th>";
                    $requete1 = "SELECT * FROM cr,utilisateur WHERE cr.num_utilisateur=utilisateur.num";
                    $resultat1 = mysqli_query($connexion, $requete1);
                    while($donnees = mysqli_fetch_assoc($resultat1))
                    {
                        $nom=$donnees['nom'];
                        $prenom=$donnees['prenom'];
                        $email=$donnees['email'];
                        if ($donnees['option']==1)
                        {
                        $option="slam";
                        }
                        else 
                        {
                        $option="sisr";
                        }
                        
                    }   
                    echo "<th> $nom </th>
                    <th>$prenom</th>
                    <th>$email</th>
                    <th>$option</th></tr>";
                }
            }
            echo "</table><br>";
            echo "<FORM method='post' action='index.php'> <button type=submit name='deco'> DECONNEXION </button> </FORM>";
        }
    }

    





?>

